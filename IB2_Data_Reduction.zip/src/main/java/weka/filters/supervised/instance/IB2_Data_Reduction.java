package weka.filters.supervised.instance;

/*
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; either version 2 of the License, or
 *    (at your option) any later version.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *    GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 *    Resample.java
 *    Copyright (C) 2002 University of Waikato, Hamilton, New Zealand
 *
 */


import weka.classifiers.lazy.IBk;
import weka.classifiers.rules.ZeroR;
import weka.core.Capabilities;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.OptionHandler;
import weka.core.RevisionUtils;
import weka.core.Utils;
import weka.core.Capabilities.Capability;
import weka.filters.Filter;
import weka.filters.SupervisedFilter;
import weka.core.neighboursearch.LinearNNSearch;
import weka.core.neighboursearch.NearestNeighbourSearch;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;

import javax.swing.JOptionPane;

/** 
 <!-- globalinfo-start -->
 * Produces a random subsample of a dataset using either sampling with replacement or without replacement.<br/>
 * The original dataset must fit entirely in memory. The number of instances in the generated dataset may be specified. The dataset must have a nominal class attribute. If not, use the unsupervised version. The filter can be made to maintain the class distribution in the subsample, or to bias the class distribution toward a uniform distribution. When used in batch mode (i.e. in the FilteredClassifier), subsequent batches are NOT resampled.
 * <p/>
 <!-- globalinfo-end -->
 * 
 <!-- options-start -->
 * Valid options are: <p/>
 * 
 * <pre> -S &lt;num&gt;
 *  Specify the random number seed (default 1)</pre>
 * 
 * <pre> -Z &lt;num&gt;
 *  The size of the output dataset, as a percentage of
 *  the input dataset (default 100)</pre>
 * 
 * <pre> -B &lt;num&gt;
 *  Bias factor towards uniform class distribution.
 *  0 = distribution in input data -- 1 = uniform distribution.
 *  (default 0)</pre>
 * 
 * <pre> -no-replacement
 *  Disables replacement of instances
 *  (default: with replacement)</pre>
 * 
 * <pre> -V
 *  Inverts the selection - only available with '-no-replacement'.</pre>
 * 
 <!-- options-end -->
 *
 * @author Len Trigg (len@reeltwo.com)
 * @author FracPete (fracpete at waikato dot ac dot nz)
 * @version $Revision: 5542 $ 
 */



public class IB2_Data_Reduction 
	
	  extends Filter 
	  implements SupervisedFilter, OptionHandler {
	  
	  /** for serialization. */
	  static final long serialVersionUID = 7079064953548300681L;

	  protected int k = 1;
	  
	  protected NearestNeighbourSearch m_NNSearch = new LinearNNSearch();

	private int cnt=0;


	  
	  

	  public String globalInfo() {
	    return 
	        "IB2 is a one-pass algorithm for Data Reduction " +
	        "It is non-parametric and order dependent";
	    }

	  /**
	   * Returns an enumeration describing the available options.
	   *
	   * @return an enumeration of all the available options.
	   */
	 
	  
	  public Enumeration listOptions() {
	    Vector result = new Vector();

	    return result.elements();
	  }



	  /**
	   * Parses a given list of options. <p/>
	   * 
	   <!-- options-start -->
	   * Valid options are: <p/>
	   * 
	   * <pre> -S &lt;num&gt;
	   *  Specify the random number seed (default 1)</pre>
	   * 
	   * <pre> -Z &lt;num&gt;
	   *  The size of the output dataset, as a percentage of
	   *  the input dataset (default 100)</pre>
	   * 
	   * <pre> -B &lt;num&gt;
	   *  Bias factor towards uniform class distribution.
	   *  0 = distribution in input data -- 1 = uniform distribution.
	   *  (default 0)</pre>
	   * 
	   * <pre> -no-replacement
	   *  Disables replacement of instances
	   *  (default: with replacement)</pre>
	   * 
	   * <pre> -V
	   *  Inverts the selection - only available with '-no-replacement'.</pre>
	   * 
	   <!-- options-end -->
	   *
	   * @param options the list of options as an array of strings
	   * @throws Exception if an option is not supported
	   */
	  
	  public void setOptions(String[] options) throws Exception {
	    String	tmpStr;
	    


	    if (getInputFormat() != null) {
	      setInputFormat(getInputFormat());
	    }
	  }

	  
	  
	  /**
	   * Gets the current settings of the filter.
	   *
	   * @return an array of strings suitable for passing to setOptions
	   */
	  
	  
	  
	 
	  
	  public String [] getOptions() {
	    Vector<String>	result;

	    result = new Vector<String>();


	    
	    return result.toArray(new String[result.size()]);
	  }
	    
	  
	  
	  
	  
	  
	 
	  
	  /**
	   * Returns the tip text for this property.
	   *
	   * @return tip text for this property suitable for
	   * displaying in the explorer/experimenter gui
	   */
	  
	  /*
	  public String KTipText() {
	    return "Sets the number of neighbours. k";
	  }
	  
	  */
	  
	  
	  /**
	   * Gets the random number seed.
	   *
	   * @return the random number seed.
	   */
	  
	  /*
	  public int getKappa() {
	    return k;
	  }
	  */
	  
	  
	  
	  
	  /**
	   * Sets the random number seed.
	   *
	   * @param newSeed the new random number seed.
	   */
	  
	  
	  /*
	  public void setKappa(int kappa) {
	    k = kappa;
	  }
	    */
	  
	  
	  /** 
	   * Returns the Capabilities of this filter.
	   *
	   * @return            the capabilities of this object
	   * @see               Capabilities
	   */
	  public Capabilities getCapabilities() {
	    Capabilities result = super.getCapabilities();
	    result.disableAll();

	    // attributes
	    result.enableAllAttributes();
	    result.enable(Capability.MISSING_VALUES);
	    
	    // class
	    result.enable(Capability.NOMINAL_CLASS);
	    
	    return result;
	  }
	  /**
	   * Sets the format of the input instances.
	   *
	   * @param instanceInfo an Instances object containing the input 
	   * instance structure (any instances contained in the object are 
	   * ignored - only the structure is required).
	   * @return true if the outputFormat may be collected immediately
	   * @throws Exception if the input format can't be set 
	   * successfully
	   */
	  public boolean setInputFormat(Instances instanceInfo) 
	       throws Exception {

	    super.setInputFormat(instanceInfo);
	    setOutputFormat(instanceInfo);
	    return true;
	  }

	  
	  
	  
	  
	  
	  
	  
	  
	  /**
	   * Input an instance for filtering. Filter requires all
	   * training instances be read before producing output.
	   *
	   * @param instance the input instance
	   * @return true if the filtered instance may now be
	   * collected with output().
	   * @throws IllegalStateException if no input structure has been defined
	   */
	  public boolean input(Instance instance) {

	    if (getInputFormat() == null) {
	      throw new IllegalStateException("No input instance format defined");
	    }
	    if (m_NewBatch) {
	      resetQueue();
	      m_NewBatch = false;
	    }
	    if (isFirstBatchDone()) {
	      push(instance);
	      return true;
	    } else {
	      bufferInput(instance);
	      return false;
	    }
	  
	  }
	  
	  
	  
	
	  
	    public boolean batchFinished() throws Exception {

	        if (getInputFormat() == null) {
	          throw new IllegalStateException("No input instance format defined");
	        }

	        
	        
	        
	        if (!isFirstBatchDone()) {
            
	            

	        	m_NNSearch.setInstances(getInputFormat());

	            
	        	// remove instances with missing class	
	        	getInputFormat().deleteWithMissingClass();
	        	
	        	
	        	
	        	//Set the data to be reduced
	        	
	            for(int i=0; i< getInputFormat().numInstances()  ; i++){
	            
	                m_NNSearch.addInstanceInfo(getInputFormat().instance(i));

	            }
	            
	            
	            
	            // for each x which beloongs to Training Set, do
	            for(int i=0; i< getInputFormat().numInstances()  ; i++){
		            
	                            
	                        	
	            	//NN = Nearest Neighbour of x in the Condensing Set
	            	Instance nearestInstance = m_NNSearch.nearestNeighbour(getInputFormat().instance(i));
	            	

           
	            	
	            	
	            	
	            	//If NNclass <> Xclass then
	            	if(nearestInstance.classValue() == getInputFormat().instance(i).classValue()){

	            	//Condensing Set = Condensing Set Union x
	            		
	            	// Insert that filtered instance 
	            	 push( (Instance) getInputFormat().instance(i) );
	            	 
					cnt++;
	            }
	            }
	            	 
	            int reducedInstances = getInputFormat().numInstances() - cnt;
	            double reductionRate = reducedInstances / (double) getInputFormat().numInstances() * 100;

	            
	           JOptionPane.showMessageDialog(null, "Total reduction is: "+reducedInstances +" Instances, Rate: " +String.format( "%.2f", reductionRate )+ " %" );
	            
	        }
	        flushInput();

	        m_NewBatch = true;
	        m_FirstBatchDone = true;
	        return (numPendingOutput() != 0);
	      }
	    
	    
  

  
  

/**
 * Returns the revision string.
 * 
 * @return		the revision
 */
public String getRevision() {
  return RevisionUtils.extract("$Revision: 5542 $");
}

/**
 * Main method for testing this class.
 *
 * @param argv should contain arguments to the filter: 
 * use -h for help
 */
public static void main(String [] argv) {
  runFilter(new Resample(), argv);
}
}
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	


